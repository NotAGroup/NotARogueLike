using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using System;
using TMPro;
using System.Text;

public class InventoryUI : MonoBehaviour
{
    private Player player;
    private Inventory inventory;

    [Header("Rendering")]
    public GameObject slotPrefab;
    public Transform slotParent;

    // transforms that define slot positions
    public RectTransform slotTransformBotLeft;
    public RectTransform slotTransformBotRight;
    public RectTransform slotTransformTopLeft;

    [Header("Selected Item")]
    public TMP_Text itemNameText;
    public TMP_Text itemDescriptionText;
    public TMP_Text itemBuffText;
    
    public int  numColumns;
    private int numHotbarSlots;
    private int numSlots;

    // selection state
    public int currentSlot;
    private int grabbedSourceSlot;
    private bool grabbed { get => grabbedSourceSlot >= 0; }

    // instantiated slots
    private GameObject[] slots = null;

    void UpdateSelectedItem(ItemDefinition item, int count)
    {
        if (item == null)
        {
            itemNameText.text = "Nothing";
            itemDescriptionText.text = "This is a free slot in your bag";
            itemBuffText.text = "...";
            return;
        }

        // name and count
        if (count > 1) 
        {
            itemNameText.text = String.Format("{0}x {1}", count, item.displayName);
        } 
        else 
        {
            itemNameText.text = item.displayName;
        }


        // description
        itemDescriptionText.text = item.description;

        // buffs
        StringBuilder builder = new();
        if (item.itemBuffs != null && item.itemBuffs.definitions.Length > 0)
        {
            foreach (var pair in item.itemBuffs.definitions)
            {
                string stat = pair.key;
                float value = pair.def.value;
                char op = pair.def.operation == ScalingFormula.Operation.Multiplication ? 'x' : '+';
                builder.AppendFormat("\n\t{0}: {1}{2}", stat, op, value);
            }
        }
        itemBuffText.text = builder.ToString();
    }

    void InitializeSlots() {
        grabbedSourceSlot = -1;
        numSlots = inventory.numItemSlots;
        numHotbarSlots = inventory.numHotbarSlots;
        slots = new GameObject[numSlots];

        for (int i = 0; i < numSlots; i++) {
            slots[i] = Instantiate(slotPrefab, slotParent);

            // coefficients
            int numRows = numSlots / numColumns;
            float right = (float)(i % numColumns) / (numColumns - 1);
            float up = (float)(i / numColumns) / (numRows - 1);

            // lerp position
            Vector2 pos1 = Vector2.Lerp(slotTransformBotLeft.localPosition, slotTransformBotRight.localPosition, right);
            Vector2 pos2 = Vector2.Lerp(slotTransformBotLeft.localPosition, slotTransformTopLeft.localPosition, up);

            // slotTransformBotLeft has been added twice, so subtract it once here
            RectTransform target = slots[i].GetComponent<RectTransform>();
            target.localPosition = pos1 + pos2 - (Vector2)slotTransformBotLeft.localPosition;
        }
    }

    void UpdateSlots() {
        for (int i = 0; i < slots.Length; i++) {
            GameObject slot = slots[i];
            ItemHotbarSlot s = slot.GetComponent<ItemHotbarSlot>();

            ItemSlot slotToShow = inventory.items[i];
            // if currently moving an item, show preview of items after swap
            if (grabbed)
            {
                if (i == currentSlot)
                {
                    slotToShow = inventory.items[grabbedSourceSlot];
                }
                else if (i == grabbedSourceSlot)
                {
                    slotToShow = inventory.items[currentSlot];
                }
            }

            s.SetItem(slotToShow.storedItem, slotToShow.count);
            s.SetSelected(i == currentSlot);
            slot.GetComponent<Button>().onClick.AddListener(delegate { OnClick(i); });
        }

        ItemSlot selected = inventory.items[currentSlot];
        UpdateSelectedItem(selected.storedItem, selected.count);
    }

    void OnClick(int slot) {
        Debug.Log("slot " + slot + " has been clicked");
    }

    private void SwitchSlot(bool right) {
        int newSlot = right ? ((currentSlot + 1 + numSlots) % numSlots) : (currentSlot - 1 + numSlots) % numSlots;
        currentSlot = newSlot;

        UpdateSlots();
    }

    public void MoveSelection(Vector2 delta) {
        if (numSlots == 0) return;
        int newSlot = (currentSlot + (int)Math.Round(delta.x) + numSlots) % numSlots;
        newSlot = (newSlot + (int)Math.Round(delta.y) * numColumns + numSlots) % numSlots;
        currentSlot = newSlot;

        UpdateSlots();
    }

    public void ToggleItemGrabbed() {
        if (grabbed)
        {
            inventory.items.SwapItems(currentSlot, grabbedSourceSlot);
            grabbedSourceSlot = -1;
        }
        else 
        {
            grabbedSourceSlot = currentSlot;
        }

        UpdateSlots();
    }

    void OnEnable() {
        player = GameObject.Find("Player").GetComponent<Player>();
        inventory = GameObject.Find("Player").GetComponent<Inventory>();
    
        if (slots == null || slots.Length != inventory.numItemSlots)
            InitializeSlots();

        UpdateSlots();
    }
}
