using UnityEngine;
using System;
using System.Text;

using TMPro;

public class UpgradeUI : MonoBehaviour
{
    [Header("Rendering")]
    public GameObject statUIPrefab;

    // transforms that define slot positions
    public RectTransform statTransformStart;
    public RectTransform statTransformEnd;

    [Header("Stat information")]
    public TMP_Text statNameText;
    public TMP_Text statInfoText;

    private int selectedIndex;
    public BaseStatKey selectedStat { get => (BaseStatKey)stats.GetValue(selectedIndex); }

    private GameObject[] uiInstances;
    private UpgradeCostDefinitions defs;
    private StatScalingDefinitions scalingDefs;
    private PlayerUpgrades upgrades;
    private GameObject player;

    // get array of stats
    private Array stats = Enum.GetValues(typeof(BaseStatKey));

    // 
    public void MoveSelection(Vector2 delta) 
    {
        selectedIndex = (selectedIndex - (int)delta.y + stats.Length) % stats.Length;
        UpdateUpgrades();
    }

    public void TryUpgrade() 
    {  
        upgrades.TryUpgrade(selectedStat);
        UpdateUpgrades();
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Awake()
    {
        defs = GameObject.Find("Definitions").GetComponent<UpgradeCostDefinitions>();
        scalingDefs = GameObject.Find("Definitions").GetComponent<StatScalingDefinitions>();
        player = GameObject.Find("Player");
        upgrades = player.GetComponent<PlayerUpgrades>();
    }

    void OnEnable() 
    {
        // clear old ui objects
        if (uiInstances == null) {
            uiInstances = new GameObject[stats.Length];
        }

        // create ui element for each stat
        int index = 0;
        foreach(BaseStatKey key in stats) {
            if (uiInstances[index] != null) continue;

            var obj = Instantiate(statUIPrefab, transform);
            RectTransform target = obj.GetComponent<RectTransform>();
            target.localPosition = Vector2.Lerp(statTransformStart.localPosition, statTransformEnd.localPosition, (float)index / (stats.Length - 1));
            target.localScale    = Vector2.Lerp(statTransformStart.localScale, statTransformEnd.localScale, (float)index / (stats.Length - 1));

            uiInstances[index] = obj;
            index++;
        }

        // disable preview gameobjects
        statTransformStart.gameObject.SetActive(false);
        statTransformEnd.gameObject.SetActive(false);

        UpdateUpgrades();
    }

    public void UpdateUpgrades() {
        int index = 0;
        foreach (GameObject i in uiInstances) {
            var disp = i.GetComponent<StatDisplay>();
            var stat = (BaseStatKey)stats.GetValue(index);
            int currentLevel = player.GetComponent<PlayerUpgrades>()[stat];
            int maxLevel = defs.MaxLevel(stat);
            int[] costs = defs[stat];
            int cost = (costs != null && currentLevel < costs.Length) ? costs[currentLevel] : -1;

            disp.SetStat(stat, currentLevel, maxLevel);
            disp.SetSelected(index == selectedIndex);
            disp.SetUpgradeable(currentLevel < maxLevel);
            disp.SetCost(cost);

            index++;
        }

        BaseStatKey selection = selectedStat;
        statNameText.text = Enum.GetName(typeof(BaseStatKey), selection);
        statInfoText.text = ComputeUpgradeDescription(selection);
    }
    
    private string ComputeUpgradeDescription(BaseStatKey baseStat) {
        StringBuilder builder = new();

        // iterate through different stats
        foreach (StatKey key in Enum.GetValues(typeof(StatKey))) {
            var definition = scalingDefs[key];
            float current   = definition.ComputeFrom(upgrades.levels);
            float upgraded  = definition.ComputeWithOverride(upgrades.levels, baseStat, upgrades[baseStat] + 1);

            // skip if not changed by upgrade
            if (current == upgraded) continue;

            // show relative change if upgraded
            builder.AppendFormat("x{1:0.00} {0,-20}\n", key.ToString(), current / upgraded); 
        }

        return builder.ToString();
    }
}
